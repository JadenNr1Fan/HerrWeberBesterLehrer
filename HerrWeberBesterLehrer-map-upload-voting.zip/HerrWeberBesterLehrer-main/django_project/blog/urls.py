from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='blog-home'),
    path('about/', views.about, name='blog-about'),
    path('vote/<int:image_id>/', views.vote_image, name='vote-image'),
]
