# Manually created for map uploads, file support and voting.

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('gallery', '0002_sceneryimage_latitude_sceneryimage_longitude'),
    ]

    operations = [
        migrations.AlterField(
            model_name='sceneryimage',
            name='image',
            field=models.FileField(upload_to='scenery_images/'),
        ),
        migrations.AddField(
            model_name='sceneryimage',
            name='likes',
            field=models.PositiveIntegerField(default=0),
        ),
        migrations.AddField(
            model_name='sceneryimage',
            name='dislikes',
            field=models.PositiveIntegerField(default=0),
        ),
    ]
